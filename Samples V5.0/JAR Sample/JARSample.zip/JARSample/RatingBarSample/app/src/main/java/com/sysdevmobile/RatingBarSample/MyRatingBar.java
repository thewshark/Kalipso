package com.sysdevmobile.RatingBarSample;

import android.app.ActionBar;
import android.view.View;
import android.widget.AbsoluteLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;

import com.sysdevsolutions.external.kclientv50.KExternalEventsInterface;

public class MyRatingBar {
    static KExternalEventsInterface mEventsInterface;
    static RatingBar mRatingBar = null;

    public static void LoadRatingBar(View placeholder, KExternalEventsInterface eventsInterface)
    {
        mEventsInterface= eventsInterface;

        AbsoluteLayout parentLayout = (AbsoluteLayout)placeholder.getParent();
        AbsoluteLayout.LayoutParams layoutParams = (AbsoluteLayout.LayoutParams)placeholder.getLayoutParams();

        RelativeLayout myLayout = new RelativeLayout(placeholder.getContext());
        parentLayout.addView(myLayout, layoutParams);

        mRatingBar = new RatingBar(placeholder.getContext());
        mRatingBar.setNumStars(5);
        mRatingBar.setRating(3f);
        mEventsInterface.NotifyTopForm(new String[] {"RATING_CHANGED", String.valueOf(3)});

        mRatingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                mEventsInterface.NotifyTopForm(new String[] {"RATING_CHANGED", String.valueOf(v)});
            }
        });


        myLayout.addView(mRatingBar, new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT));
    }

    public static void SetRatting(float ratting)
    {
        if(mRatingBar!=null)
            mRatingBar.setRating(ratting);
    }
}
