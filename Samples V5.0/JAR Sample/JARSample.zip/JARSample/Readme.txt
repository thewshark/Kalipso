This sample shows how to use Kalipso RunJAR() action to invoke external code.

[RatingBarSample] folder contains the Android Studio project
This project create a RatingBar control and adds it to the user interface


[AndroidAPKRatingBarSample] folder contains the Kalipso Project
This project loads the APK and calls its functions to add the RatingBar controlo to the Form


If you change the Android studio project, recompile the APK, and copy the RatingBarSample.apk file to the [AndroidAPKRatingBarSample\Files To Send] folder
