package com.sysdevsolutions.idatascanplugin;

public class Symbology {
    /** Aztec Code */
    public static final int SYM_AZTEC = 0;
    /** Codabar */
    public static final int SYM_CODABAR = 1;
    /** Code 11 */
    public static final int SYM_CODE11 = 2;
    /** Code 128 */
    public static final int SYM_CODE128 = 3;
    /** Code 39 */
    public static final int SYM_CODE39 = 4;
    /** Code 93 */
    public static final int SYM_CODE93 = 6;
    /** EAN·UCC Composite */
    public static final int SYM_COMPOSITE = 7;
    /** Data Matrix */
    public static final int SYM_DATAMATRIX = 8;
    /** EAN-8 */
    public static final int SYM_EAN8 = 9;
    /** EAN-13 */
    public static final int SYM_EAN13 = 10;
    /** Interleaved 2 of 5 */
    public static final int SYM_INT25 = 11;
    /** Maxicode */
    public static final int SYM_MAXICODE = 12;
    /** Micro PDF */
    public static final int SYM_MICROPDF = 13;

    /** PDF417 */
    public static final int SYM_PDF417 = 15;

    /** QR Code */
    public static final int SYM_QR = 17;
    /** Reduced Space Symbology (RSS-14, RSS Limited, RSS Expanded) */
    public static final int SYM_RSS = 18;
    /** UPC-A */
    public static final int SYM_UPCA = 19;
    /** UPC-E0 */
    public static final int SYM_UPCE0 = 20;
    /** UPC-E1 */
    public static final int SYM_UPCE1 = 21;
    /** ISBT 128 */
    public static final int SYM_ISBT = 22;
    /** British Post [2D Postal] */
    public static final int SYM_BPO = 23;
    /** Canadian Post [2D Postal] */
    public static final int SYM_CANPOST = 24;
    /** Australian Post [2D Postal] */
    public static final int SYM_AUSPOST = 25;
    /** Straight 2 of 5 IATA (two-bar start/stop) */
    public static final int SYM_IATA25 = 26;
    /** Codablock F */
    public static final int SYM_CODABLOCK = 27;
    /** Japanese Post [2D Postal] */
    public static final int SYM_JAPOST = 28;
    /** Planet Code [2D Postal] */
    public static final int SYM_PLANET = 29;
    /** KIX (Netherlands) Post [2D Postal] */
    public static final int SYM_DUTCHPOST = 30;
    /** MSI */
    public static final int SYM_MSI = 31;
    /** TCIF Linked Code 39 (TLC39) */
    public static final int SYM_TLCODE39 = 32;
    /** Trioptic Code */
    public static final int SYM_TRIOPTIC = 33;
    /** Code 32 Italian Pharmacy Code */
    public static final int SYM_CODE32 = 34;
    /** Straight 2 of 5 Industrial (three-bar start/stop) */
    public static final int SYM_STRT25 = 35;
    /** Matrix 2 of 5 */
    public static final int SYM_MATRIX25 = 36;
    /** China Post */
    public static final int SYM_CHINAPOST = 38;
    /** Korean Post */
    public static final int SYM_KOREAPOST = 39;
    /** Telepen */
    public static final int SYM_TELEPEN = 40;

    /** Coupon Code */
    public static final int SYM_COUPONCODE = 43;
    /** USPS 4 State (Intelligent Mail Barcode) [2D Postal] */
    public static final int SYM_USPS4CB = 44;
    /** UPU 4 State [2D Postal] */
    public static final int SYM_IDTAG = 45;
    /** GS1 128 */
    public static final int SYM_GS1_128 = 47;
    /** Hanxin */
    public static final int SYM_HANXIN = 48;
    /** @deprecated Grid Matrix */
    // public static final int SYM_GRIDMATRIX = 49;
    /** Used to default and disable postal codes */
    public static final int SYM_POSTALS = 50;
    /** Used to enable SYM_PLANET, SYM_POSTNET, SYM_USPS4CB & SYM_IDTAG */
    public static final int SYM_US_POSTALS1 = 51;
}
