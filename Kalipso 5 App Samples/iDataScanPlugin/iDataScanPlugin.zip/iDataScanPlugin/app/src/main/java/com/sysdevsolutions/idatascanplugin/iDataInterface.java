package com.sysdevsolutions.idatascanplugin;

import android.content.Context;
import android.content.Intent;

public class iDataInterface {
	/********************************************Constant definition of Scan interface ******************************/
	//Open/close the scanner 
	public static final String KEY_BARCODE_ENABLESCANNER_ACTION = "android.intent.action.BARCODESCAN";
	
	//Start to scan
	public static final String KEY_BARCODE_STARTSCAN_ACTION = "android.intent.action.BARCODESTARTSCAN";
	
	//Stop scanning
	public static final String KEY_BARCODE_STOPSCAN_ACTION = "android.intent.action.BARCODESTOPSCAN";
	

	//Lock the scan button 
	public static final String KEY_LOCK_SCAN_ACTION = "android.intent.action.BARCODELOCKSCANKEY";
	
	//Unlock the scan button
	public static final String KEY_UNLOCK_SCAN_ACTION = "android.intent.action.BARCODEUNLOCKSCANKEY";
	
	//Prompt tone: android.intent.action.BEEP
	public static final String KEY_BEEP_ACTION = "android.intent.action.BEEP";
	
	//Scan failed sound
	public static final String KEY_FAILUREBEEP_ACTION = "android.intent.action.FAILUREBEEP";
	
	//Vibration: android.intent.action.VIBRATE
	public static final String KEY_VIBRATE_ACTION = "android.intent.action.VIBRATE";
	
	//Broadcast mode or not? 
	public static final String KEY_OUTPUT_ACTION = "android.intent.action.BARCODEOUTPUT";
	//Setting coding format by broadcasting 
	public static final String KEY_CHARSET_ACTION = "android.intent.actionCHARSET";  
	
	//Power saving mode
	public static final String KEY_POWER_ACTION = "android.intent.action.POWER";
	
	//Additional content
	public static final String KEY_TERMINATOR_ACTION = "android.intent.TERMINATOR";
	
	//Display notification bar icon: android.intent.action.SHOWNOTICEICON
	public static final String KEY_SHOWNOTICEICON_ACTION  = "android.intent.action.SHOWNOTICEICON";
	
	//Display APP icon: android.intent.action.SHOWAPPICON
	public static final String KEY_SHOWICON_ACTION  = "android.intent.action.SHOWAPPICON";

	//Show the UI of scan setting  
	public static final String KEY_SHOWISCANUI = "com.android.auto.iscan.show_setting_ui";

	//Add prefix 
	public static final String KEY_PREFIX_ACTION = "android.intent.action.PREFIX";
	
	//Add suffix 
	public static final String KEY_SUFFIX_ACTION = "android.intent.action.SUFFIX";
	
	//Trim left 
	public static final String KEY_TRIMLEFT_ACTION = "android.intent.action.TRIMLEFT";
	
	//Trim the right ? characters of scan result 
	public static final String KEY_TRIMRIGHT_ACTION = "android.intent.action.TRIMRIGHT";
	
	//Control the right LED light on the top of screen
	public static final String KEY_LIGHT_ACTION = "android.intent.action.LIGHT";  
	
	//Set the timeout
	public static final String KEY_TIMEOUT_ACTION = "android.intent.action.TIMEOUT";
	
	//Filter specific characters of scanning result 
	public static final String KEY_FILTERCHARACTER_ACTION = "android.intent.action.FILTERCHARACTER";
	
	//Continuous scanning 
	public static final String KEY_CONTINUCESCAN_ACTION = "android.intent.action.BARCODECONTINUCESCAN";
	
	//Time interval of continuous scanning 
	public static final String KEY_INTERVALTIME_ACTION = "android.intent.action.INTERVALTIME";
	
	//Delete the original content in edit box or not?
	public static final String KEY_DELELCTED_ACTION = "android.intent.action.DELELCTED";
	
	//Reset to the default 
	public static final String KEY_RESET_ACTION = "android.intent.action.RESET";
	
	//Scan button configuration 
	public static final String SCANKEY_CONFIG_ACTION = "android.intent.action.scankeyConfig";
	
	//Scan failed broadcast 
	public static final String KEY_FAILUREBROADCAST_ACTION = "android.intent.action.FAILUREBROADCAST";
	
	//Set the maximum number of decoding 
	public static final String KEY_SETMAXMULTIREADCOUNT_ACTION = "android.intent.action.MAXMULTIREADCOUNT";


	public static final String KEY_ENABLESYMBOLOGIES_ACTION = "android.intent.action.ENABLESYMBOLOGIES";
	/****************************************************************************************************/

	
	/********************************************Constant definition of System interface******************************/
	
	static final String  SET_STATUSBAR_EXPAND = "com.android.set.statusbar_expand";
	static final String  SET_USB_DEBUG = "com.android.set.usb_debug";
	static final String  SET_INSTALL_PACKAGE = "com.android.set.install.package";
	static final String  SET_SCREEN_LOCK = "com.android.set.screen_lock";
	static final String  SET_CFG_WAKEUP_ANYKEY = "com.android.set.cfg.wakeup.anykey";
	static final String  SET_UNINSTALL_PACKAGE= "com.android.set.uninstall.package";          
	static final String  SET_SYSTEM_TIME="com.android.set.system.time"; 
	static final String  SET_KEYBOARD_CHANGE = "com.android.disable.keyboard.change";
	static final String SET_INSTALL_PACKAGE_WITH_SILENCE = "com.android.set.install.packege.with.silence";
	static final String SET_INSTALL_PACKAGE_EXTRA_APK_PATH = "com.android.set.install.packege.extra.apk.path";
	static final String SET_INSTALL_PACKAGE_EXTRA_TIPS_FORMAT = "com.android.set.install.packege.extra.tips.format";
	static final String SET_SIMULATION_KEYBOARD = "com.android.simulation.keyboard";
	static final String SET_SIMULATION_KEYBOARD_STRING = "com.android.simulation.keyboard.string";
	/****************************************************************************************************/

	private Context mContext;

	public iDataInterface(Context context) {
		mContext = context;

	}

	/*********the Scan Control Interface*********************/

	/*************************************/	
	//	1.Show the UI of scan settings 
	public void ShowUI(){	
		if(mContext != null){
			Intent intent = new Intent(KEY_SHOWISCANUI);
			mContext.sendBroadcast(intent);
		}
	}

	//	2.Power up the scanner 
	public void open(){	
		if(mContext != null){
			Intent intent = new Intent(KEY_BARCODE_ENABLESCANNER_ACTION);
			intent.putExtra(KEY_BARCODE_ENABLESCANNER_ACTION, true);
			mContext.sendBroadcast(intent);
		}
	}

	//2.Power down the scanner 
	public void  close(){
		if(mContext != null){
			Intent intent = new Intent(KEY_BARCODE_ENABLESCANNER_ACTION);
			intent.putExtra(KEY_BARCODE_ENABLESCANNER_ACTION, false);
			mContext.sendBroadcast(intent);
		}

	}

	// 3. Trigger the scanner and beams 
	/*
	 * 1.You can trigger scanner in your program via this function together with scan_stop();
	 * 2.When the scanner is available,call scan_start() to trigger scaner beam and start to scan;
	 * 3.The program must call scan_start() to resume scanner status once finish scanning or timeout. 
	 * */
	public void  scan_start(){

		if(mContext != null){
			Intent intent = new Intent(KEY_BARCODE_STARTSCAN_ACTION);
			mContext.sendBroadcast(intent);
		}
	}

	//4.Stop decoding and light off.
	/**
	 *You can trigger scanner in your program via this function together with scan_stop();
	 *After calling scan_start() to trigger scanner and finish scanning,the program must call scan_stop() to resume scanner status.
	 *
	 */
	public void scan_stop(){
		if(mContext != null){
			Intent intent = new Intent(KEY_BARCODE_STOPSCAN_ACTION);
			mContext.sendBroadcast(intent);
		}
	}

	/**Lock the scan button.You can only use the scan buttons which iScan defined  if you lock it.
	 */
	public void  lockScanKey(){
		if(mContext != null){
			Intent intent = new Intent(KEY_LOCK_SCAN_ACTION);
			mContext.sendBroadcast(intent);
		}
	}

	/******
	 * Unlock the scan button. You can customize the scan button in your program after you unlock it.
	 */
	public void unlockScanKey(){
		if(mContext != null){
			Intent intent = new Intent(KEY_UNLOCK_SCAN_ACTION);
			mContext.sendBroadcast(intent);
		}
	}
	
	
	/**Output mode of scanner 
	 * mode 0: Focus mode: send the scan results to the focus edit box directly. 
	 * mode 1: Broadcast mode: your program needs to register action as the broadcast receiver of ��android.intent.action.SCANRESULT��,
	 *         and please gain the value,length and type of barcode by the following 2 lines of code in the method:onReceive(Context context, Intent arg1): 
	 * 		   --String  barocode=arg1.getStringExtra("value");
		       --int barocodelen=arg1.getIntExtra("length",0);        
	 * mode 2: Analog key output mode
	 */
	public void setOutputMode(int mode){
		if(mContext != null){
			Intent intent = new Intent(KEY_OUTPUT_ACTION);
			intent.putExtra(KEY_OUTPUT_ACTION, mode);
			mContext.sendBroadcast(intent);
		}
	}
	
	/** Enable/disable prompt tone*/
	public void enablePlayBeep(boolean enable){
		if(mContext != null){
			Intent intent = new Intent(KEY_BEEP_ACTION);
			intent.putExtra(KEY_BEEP_ACTION, enable);
			mContext.sendBroadcast(intent);
		}
	}
	
	/**Enable/disable prompt tone of scan failure */
	public void enableFailurePlayBeep(boolean enable){
		if(mContext != null){
			Intent intent = new Intent(KEY_FAILUREBEEP_ACTION);
			intent.putExtra(KEY_FAILUREBEEP_ACTION, enable);
			mContext.sendBroadcast(intent);
		}
	}


	/**Enable/disable vibration*/
	public void enablePlayVibrate(boolean enable){
		if(mContext != null){
			Intent intent = new Intent(KEY_VIBRATE_ACTION);
			intent.putExtra(KEY_VIBRATE_ACTION, enable);
			mContext.sendBroadcast(intent);
		}
	}

	/**  Additional Enter key,line feeds ect.
	 * 0 <item>null</item>
       1 <item>Additional Enter key</item>
       2 <item>Additional TAB key</item>
       3 <item>Additional line feeds</item>*/
	public void  enableAddKeyValue(int value){
		if(mContext != null){
			Intent intent = new Intent(KEY_TERMINATOR_ACTION);
			intent.putExtra(KEY_TERMINATOR_ACTION, value);
			mContext.sendBroadcast(intent);
		}
	}
	
	/************************************************************/

	//KEY_PREFIX_ACTION  *Add prefix
	public void  addPrefix(String  text){
		if(mContext != null){
			Intent intent = new Intent(KEY_PREFIX_ACTION);
			intent.putExtra(KEY_PREFIX_ACTION, text);
			mContext.sendBroadcast(intent);
		}
	}

	//KEY_SUFFIX_ACTION  *Add suffix
	public void  addSuffix(String  text){
		if(mContext != null){
			Intent intent = new Intent(KEY_SUFFIX_ACTION);
			intent.putExtra(KEY_SUFFIX_ACTION, text);
			mContext.sendBroadcast(intent);
		}
	}

	//KEY_TRIMLEFT_ACTION  *Trim the left ? characters of scan result 
	public void   interceptTrimleft  (int  num){
		if(mContext != null){
			Intent intent = new Intent(KEY_TRIMLEFT_ACTION);
			intent.putExtra(KEY_TRIMLEFT_ACTION, num);
			mContext.sendBroadcast(intent);
		}
	}

	//KEY_TRIMRIGHT_ACTION  *Trim the right ? characters of scan result 
	public void   interceptTrimright  (int  num){
		if(mContext != null){
			Intent intent = new Intent(KEY_TRIMRIGHT_ACTION);
			intent.putExtra(KEY_TRIMRIGHT_ACTION, num);
			mContext.sendBroadcast(intent);
		}
	}

	//KEY_LIGHT_ACTION  *Control the right LED light on the top of screen
	public void   lightSet (boolean enable ){
		if(mContext != null){
			Intent intent = new Intent(KEY_LIGHT_ACTION);
			intent.putExtra(KEY_LIGHT_ACTION, enable);
			mContext.sendBroadcast(intent);
		}
	}

	//KEY_TIMEOUT_ACTION  *Set the timeout
	public void   timeOutSet(int  value){
		if(mContext != null){
			Intent intent = new Intent(KEY_TIMEOUT_ACTION);
			intent.putExtra(KEY_TIMEOUT_ACTION, value);
			mContext.sendBroadcast(intent);
		}
	}

	//KEY_FILTERCHARACTER_ACTION  //Filter specific characters of scanning result 
	public void   filterCharacter (String text ){
		if(mContext != null){
			Intent intent = new Intent(KEY_FILTERCHARACTER_ACTION);
			intent.putExtra(KEY_FILTERCHARACTER_ACTION, text);
			mContext.sendBroadcast(intent);
		}
	}

	//KEY_CONTINUCESCAN_ACTION  *Enable/disable continuous scanning
	public void   continceScan (boolean enable ){
		if(mContext != null){
			Intent intent = new Intent(KEY_CONTINUCESCAN_ACTION);
			intent.putExtra(KEY_CONTINUCESCAN_ACTION, enable);
			mContext.sendBroadcast(intent);
		}
	}

	//KEY_INTERVALTIME_ACTION  *Time interval of continuous scanning 
	public void  intervalSet(int  value){
		if(mContext != null){
			Intent intent = new Intent(KEY_INTERVALTIME_ACTION);
			intent.putExtra(KEY_INTERVALTIME_ACTION, value);
			mContext.sendBroadcast(intent);
		}
	}
	//KEY_FAILUREBROADCAST_ACTION  *Scan failed broadcast 
	public void   SetErrorBroadCast (boolean enable ){
		if(mContext != null){
			Intent intent = new Intent(KEY_FAILUREBROADCAST_ACTION);
			intent.putExtra(KEY_FAILUREBROADCAST_ACTION, enable);
			mContext.sendBroadcast(intent);
		}
	}

	//KEY_RESET_ACTION  *Reset to the defaults
	public void resultScan(){	
		if(mContext != null){
			Intent intent = new Intent(KEY_RESET_ACTION);
			mContext.sendBroadcast(intent);
		}
	}

	//Enable/disable symbologies configuration
	public void setSymbologiesEnable(int symbol, boolean  enable) {
		if(mContext != null){
			Intent intent = new Intent(KEY_ENABLESYMBOLOGIES_ACTION);
			intent.putExtra("symbologies", symbol);
			intent.putExtra("enable", enable);
			mContext.sendBroadcast(intent);
		}

	}
}
