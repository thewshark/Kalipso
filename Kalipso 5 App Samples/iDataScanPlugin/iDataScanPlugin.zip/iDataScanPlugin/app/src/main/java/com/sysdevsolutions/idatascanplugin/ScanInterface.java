package com.sysdevsolutions.idatascanplugin;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.view.KeyEvent;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

import com.sysdevsolutions.external.kclientv50.KExternalEventsHandler;
import com.sysdevsolutions.external.kclientv50.KExternalEventsInterface;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPI;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPI.ConnectionType;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPIException;

public class ScanInterface extends KExternalEventsHandler implements KExternalScannerAPI {

    private KExternalEventsInterface mEventsInterface = null;
    iDataInterface mScanner=null;
    ScannerResultReceiver mScanReceiver=null;
    private static final String RES_ACTION = "android.intent.action.SCANRESULT";
    //private boolean isContinue = false;	//Flag of continuous scanning
    private boolean mIsEnabled = false;

    //Actual implementation functions for Kalipso Barcode Actions
    @Override
    public void Connect(Context ctx, Activity act, ConnectionType connectionType, String address, String userParameters, KExternalEventsInterface eventsInterface) throws KExternalScannerAPIException
    {
        mEventsInterface=eventsInterface;

        eventsInterface.AddOnAppEventListener(this);

        mScanner=new iDataInterface(ctx);
        mIsEnabled = false;

        mScanner.open();//Power up the scan engine.
        //Note:Do not call this interface frequently, Because closing the serial frequently may lead to the program die.
        //

        /**Set the output mode of scan result, parameters are 0 and 1:
         * 0:Analog output mode (Output scan results at the the cursor,and broadcast scan data at the same time);
         * 1:Broadcast Mode (only for broadcasting scan data)
         * 2:Analog key output Mode
         * */
        mScanner.setOutputMode(1);

        //mScanner.lockScanKey();
        //Lock the scan button and use iScan default scan buttons.
        //mScanner.unlockScanKey();
        //Unlock the scan button so iScan can not control the scan button,and then you can customize it yourself.
        mScanner.enablePlayBeep(true);//enable/disable beep when scan fails.
        mScanner.enableFailurePlayBeep(true);//Beeps when scan fails.
        mScanner.enablePlayVibrate(true);//enable/disable vibration
        mScanner.timeOutSet(5);//Set to scan delay 5 seconds
        mScanner.intervalSet(0); //Set the time interval of continuous scanning as 0(ms).
        mScanner.lightSet(true);//enable/disable the scan LED light on the top left
        //mScanner.addPrefix("AAA");//add prefix
        //mScanner.addSuffix("BBB");//add suffix
        //mScanner.interceptTrimleft(2); //trim the left characters of scan result
        //mScanner.interceptTrimright(3);//trim the right characters of scan result
        //mScanner.filterCharacter("9");//filter the specific character "9"
        //mScanner.enableAddKeyValue(1);//additional keys: null/ENTER/TAB/
        mScanner.enableAddKeyValue(0);//additional keys: null
        //		scanner.resultScan();//reset to the iScan defaults
        mScanner.SetErrorBroadCast(true);//broadcast the scan error

        mScanner.unlockScanKey();//Kalipso initializes the scanner in disabled state

        // You must use "android.intent.action.SCANRESULT"  as the intent filter action of scan result
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(RES_ACTION);
        //Register broadcast receiver
        mScanReceiver = new ScannerResultReceiver();
        mScanReceiver.mEventsInterface=mEventsInterface;

        ctx.registerReceiver(mScanReceiver, intentFilter);
    }

    @Override
    public void Disconnect(Context ctx, String userParameters) throws KExternalScannerAPIException {
        if(mScanReceiver!=null) {
            ctx.unregisterReceiver(mScanReceiver);
            mScanReceiver = null;
        }

        if(mScanner!=null) {
            mScanner.lockScanKey();
            mScanner.setOutputMode(0);
            mScanner.close();
            mScanner = null;
        }
    }

    @Override
    public void SetEnabled(Context ctx, boolean enabled, String userParameters) throws KExternalScannerAPIException {
        if(mScanner==null)
            throw new KExternalScannerAPIException("Not connected to scanner!");
        mIsEnabled = enabled;
        mScanner.setOutputMode(1);
        if(enabled)
            mScanner.lockScanKey();
        else
            mScanner.unlockScanKey();
    }

    @Override
    public void ScanBarcode(Context ctx, int timeOut, boolean softTrigger, ArrayList<String> scannedBarcodes, ArrayList<String> scannedBarcodeTypes, String userParameters) throws KExternalScannerAPIException {
        if(mScanner==null)
            throw new KExternalScannerAPIException("Not connected to scanner!");

        boolean wasEnabled=mIsEnabled;

        mScanReceiver.mBlockingScanObject=new Object();
        mScanReceiver.mBlockingScanFlag=new AtomicBoolean(false);
        mScanReceiver.mBlockingScanRequest=true;

        if(softTrigger)
            mScanner.scan_start();
        else
            SetEnabled(ctx, true, "");

        synchronized(mScanReceiver.mBlockingScanObject)
        {
            try {mScanReceiver.mBlockingScanObject.wait(timeOut);}
            catch (Exception e)
            {}

            if(softTrigger)
                mScanner.scan_stop();
            else if(!wasEnabled)
                SetEnabled(ctx, false, "");

            mScanReceiver.mBlockingScanRequest=false;

            if(!mScanReceiver.mBlockingScanFlag.get())
            {

                throw new KExternalScannerAPIException("Timeout waiting for scan!");
            }
        }

        mScanReceiver.mBlockingScanObject = null;
        mScanReceiver.mBlockingScanFlag = null;

        scannedBarcodes.add(mScanReceiver.mLastScanData);
        scannedBarcodeTypes.add(String.valueOf(mScanReceiver.mLastScanType));
    }

    @Override
    public void SetEnabledSymbologies(Context ctx, int[] symbologiesList, int symbologiesCount, String userParameters) throws KExternalScannerAPIException {
        throw new KExternalScannerAPIException("iData SDK does not allow to set scanner configuration!");

        /*if(mScanner==null)
            throw new KExternalScannerAPIException("Not connected to scanner!");

        */
    }

    private void SetSymbology(int symbol, int[] symbologiesList, int symbologiesCount) {
        int kalipsoID = iDataSymToKalipsoID(symbol);
        if(kalipsoID<=0)
            return;

        boolean found = false;
        for(int i=0; i<symbologiesCount; i++)
        {
            if(symbologiesList[i]==kalipsoID)
            {
                found = true;
                break;
            }
        }

        mScanner.setSymbologiesEnable(symbol, found);
    }

    private int iDataSymToKalipsoID(int symbol) {
        switch (symbol)
        {
            case Symbology.SYM_AZTEC:
                return 74;
            case Symbology.SYM_CODABAR:
                return 19;
            case Symbology.SYM_CODE11:
                return 26;
            case Symbology.SYM_CODE128:
                return 23;
            case Symbology.SYM_CODE39:
                return 13;
            case Symbology.SYM_CODE93:
                return 25;
            case Symbology.SYM_COMPOSITE:
                return 59;
            case Symbology.SYM_DATAMATRIX:
                return 40;
            case Symbology.SYM_EAN8:
                return 2;
            case Symbology.SYM_EAN13:
                return 1;
            case Symbology.SYM_INT25:
                return 15;
            case Symbology.SYM_MAXICODE:
                return 42;
            case Symbology.SYM_MICROPDF:
                return 105;
            case Symbology.SYM_PDF417:
                return 33;
            case Symbology.SYM_QR:
                return 41;
            case Symbology.SYM_RSS:
                return 37;
            case Symbology.SYM_UPCA:
                return 3;
            case Symbology.SYM_UPCE0:
                return 4;
            case Symbology.SYM_UPCE1:
                return 103;
            case Symbology.SYM_ISBT:
                return 35;
            case Symbology.SYM_BPO:
                return 63;
            case Symbology.SYM_CANPOST:
                return 64;
            case Symbology.SYM_AUSPOST:
                return 65;
            case Symbology.SYM_IATA25:
                return 101;
            case Symbology.SYM_CODABLOCK:
                return 30;
            case Symbology.SYM_JAPOST:
                return 66;
            case Symbology.SYM_PLANET:
                return 62;
            case Symbology.SYM_DUTCHPOST:
                return 67;
            case Symbology.SYM_MSI:
                return 21;
            case Symbology.SYM_TLCODE39:
                return 70;
            case Symbology.SYM_TRIOPTIC:
                return 71;
            case Symbology.SYM_CODE32:
                return 103;
            case Symbology.SYM_STRT25:
                return 16;
            case Symbology.SYM_MATRIX25:
                return 17;
            case Symbology.SYM_CHINAPOST:
                return 68;
            case Symbology.SYM_KOREAPOST:
                return 69;
            case Symbology.SYM_TELEPEN:
                return 27;
            case Symbology.SYM_COUPONCODE:
                return 102;
            case Symbology.SYM_USPS4CB:
                return 79;
            case Symbology.SYM_IDTAG:
                return -Symbology.SYM_IDTAG;
            case Symbology.SYM_GS1_128:
                return 34;
            case Symbology.SYM_HANXIN:
                return -Symbology.SYM_HANXIN;
            case Symbology.SYM_POSTALS:
                return -Symbology.SYM_US_POSTALS1;
            case Symbology.SYM_US_POSTALS1:
                return 61;
        }

        return 0;
    }

    @Override
    public void GetEnabledSymbologies(Context ctx, ArrayList<Integer> symbologiesList, String userParameters) throws KExternalScannerAPIException {
        throw new KExternalScannerAPIException("iData SDK does not allow to retrieve scanner configuration!");
        //return 0;
    }

    @Override
    public void onAppPaused(Context ctx)
    {
    }

    @Override
    public void onAppResumed(Context ctx)
    {
    }

    @Override
    public void onKeyDown(Activity act, int keyCode, KeyEvent event) {
        //This is no longer necessary, they handle this in their API
        /*if(!mIsEnabled)
            return;

        if(mScanner==null)
            return;

        if ((keyCode == 139) || (keyCode == 140) || (keyCode == 141))
        {
            if (event.getRepeatCount() == 0) {
                mScanner.scan_start();
                //			scanner.ShowUI();
            }
        }*/
    }

    @Override
    public void onKeyUp(Activity act, int keyCode, KeyEvent event) {
        //This is no longer necessary, they handle this in their API
        /*if(!mIsEnabled)
            return;

        if(mScanner==null)
            return;

        if (keyCode == 139){
            mScanner.scan_stop();
        }else if (keyCode == 140){
            mScanner.scan_stop();
        }
        else if (keyCode == 141){
            mScanner.scan_stop();

        }*/
    }


    private int ConvertTypeToKalipso(int bcType)
    {
        //They do not have a list of possible values, so we cannot convert to Kalipso codes
        return -bcType;
    }

    private class ScannerResultReceiver extends BroadcastReceiver{
        KExternalEventsInterface mEventsInterface = null;
        boolean mBlockingScanRequest=false;
        Object mBlockingScanObject=null;
        AtomicBoolean mBlockingScanFlag=null;
        String mLastScanData="";
        int mLastScanType=0;

        public void onReceive(Context context, Intent intent) {
            //Log.d("111","intent.getAction()-->"+intent.getAction());

            final String scanResult = intent.getStringExtra("value");
            int scanType=intent.getIntExtra("type",0);
            scanType=ConvertTypeToKalipso(scanType);

            /** If the length > 0, decoding success;
             *  If length = 0, decoding fail
             * */
            if (intent.getAction().equals(RES_ACTION)){
                //gain the scan result
                if(scanResult.length()>0){
                    if(mBlockingScanRequest)
                    {
                        if(mBlockingScanObject!=null) {
                            synchronized(mBlockingScanObject)
                            {
                                mLastScanData=scanResult;
                                mLastScanType=scanType;
                                if(mBlockingScanFlag!=null)
                                    mBlockingScanFlag.set(true);

                                mBlockingScanObject.notify();
                            }
                        }
                    }
                    else if(mEventsInterface!=null)
                    {
                        mEventsInterface.BarcodeScanned(scanResult, scanType, "");
                    }
                    //Log.d("111","----->Scan Succeed！");

                    //tvScanResult.append("Barcode："+scanResult+"\n");
                }else{//else if(scanResult.length()==0)
                    /**There are two conditions to use scan failure prompts:
                     *1, Please open scan failure prompt interface. This can only be used in Broadcast Mode.
                       					  *2, Determine whether the decoding succeed via the barcode length. When length=0,decoding fails.
                     * */
                    //Log.d("111","----->Scan Failed！");
                    //Toast.makeText(getApplicationContext(), "Decoding Failed！", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
